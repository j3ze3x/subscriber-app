<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Subscriber;

class SubscriberController extends Controller
{
    public function index(){
        return view('subscriber.index');
    }

    public function search(Request $request){
        $q = Subscriber::query();
        if($request->search){
            $q->where('name','like','%'.$request->search.'%')
              ->orWhere('phone','like','%'.$request->search.'%');
        }
        return response()->json($q->get());
    }
}

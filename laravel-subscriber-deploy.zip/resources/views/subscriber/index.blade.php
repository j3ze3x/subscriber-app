<!DOCTYPE html>
<html>
<head>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container mt-4">
<h3>Subscriber Dashboard</h3>

<input type="text" id="search" class="form-control mb-3" placeholder="Search">

<table class="table table-bordered">
<thead>
<tr>
<th>Phone</th>
<th>Name</th>
<th>Tier</th>
<th>Status</th>
</tr>
</thead>
<tbody id="result"></tbody>
</table>
</div>

<script>
function loadData(){
    $.get('/subscriber-search',{search:$('#search').val()},function(data){
        let rows='';
        data.forEach(r=>{
            rows+=`<tr>
            <td>${r.phone}</td>
            <td>${r.name}</td>
            <td>${r.tier}</td>
            <td>${r.status}</td>
            </tr>`;
        });
        $('#result').html(rows);
    });
}
$('#search').on('keyup',loadData);
loadData();
</script>
</body>
</html>

<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubscriberController;

Route::get('/subscriber',[SubscriberController::class,'index']);
Route::get('/subscriber-search',[SubscriberController::class,'search']);
